package accountname.productname.web.packname.main;


public class Transactions {
	public static String referredOrDeclined;

	public static void tansaction (String TransactionName ) throws Exception {
		referredOrDeclined = TestSuite.getTestdata().getData ("ResultDeclineRefer").trim ();
		String TransactionName1 = TransactionName.toUpperCase();
		new executeTest().launchApplication (Utils.getURL());

		Switch (TransactionName1) {

		case "GET QUOTE"
		Transaction_NewBusiness.process();
		break;

		case "BUY POLICY"
		Transaction_NewBusiness.process();
		break;
		
		case "REGISTER"
		Transaction_Register.process();
		break;

		}

	}
}
