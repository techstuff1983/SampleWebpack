package accountname.productname.web.packname.pages;

public class Page_Register {

	@ReportingInfo (info = "Register link")
	@FindBy(xpath= "")
	public WebElement btnRegister;
	
}
