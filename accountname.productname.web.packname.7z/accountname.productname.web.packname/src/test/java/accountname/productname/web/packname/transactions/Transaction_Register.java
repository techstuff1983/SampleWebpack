package accountname.productname.web.packname.transactions;

import accountname.productname.web.packname.actions.Action_Register;

public class Transaction_Register {

	public static void process () throws Exception {
		(new Action_Register()).Execute();
		(new Action_YourDetails()).Execute();
		(new Action_Covers()).Execute();
	}
}
