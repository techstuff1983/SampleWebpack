package accountname.productname.web.packname.utilities;

public class Utils {

	public static String sEnvironment = null;
	public static String sURL = null;

	public static void getApplicationInfo(ExtentReports report) {
		sEnvironment = System.getProperty("Environment");
		sEnvironment = sEnvironment == null ? PropertyReader.getProperty().environment().toUpperCase() : sEnvironment;
		report.setSystemInfor("Environment", sEnvironment);
		report.setSystemInfor("URL", getURL());
	}

	public static String getURL() {
		System.out.println("Execution is on " + sEnvironment);
		switch (sEnvironment.toUpperCase()) {
		case "RUNWAY":
			sURL = PropertyReader.getProperty().urlRunway();
			break;

		case "STAGING":
			sURL = PropertyReader.getProperty().urlRunway();
			break;
		default:
			LoggingHelper.error("Environment not set in properties");
		}
	}
}