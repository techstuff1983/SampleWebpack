package accountname.productname.web.packname.actions;

import java.awt.AWTException;
import java.io.IOException;

import accountname.productname.web.packname.pages.Page_Register;

public class Action_Register extends BaseAction {
	public Action_Register () {
		super();
	}
	public void Execute () throws IOException, InterruptedException, AWTException {

		Page_Register Pg = pageFactory.initElements (AutomationExecutor.getDriver(), Page_Register.class);

		if(executeTest.TransactionName.equalIgnoreCase("Register"))	{
				forcedClick(Pg.btnRegister, CommonHelper.getReportingInfo(Pg, btnRegister));
				BrowserHelper.waitUntilElementIsVisible(Pg.btnSubmit);
				setValue (Pg.txtFirstName, TestSuite.getTestData(),getData ("FirstName").trim(),CommonHelper.getReportingInfo(Pg, txtFirstName));
				setValue (Pg.txtLastName, TestSuite.getTestData(),getData ("LastName").trim(),CommonHelper.getReportingInfo(Pg, txtLastName));
				setValue (Pg.txtDOB, TestSuite.getTestData(),getData ("LastName").trim(),CommonHelper.getReportingInfo(Pg, txtDOB));
				elementClick (Pg.btnSubmit, CommonHelper.getReportingInfo(Pg, btnSubmit));
		} else if (Login functionality) {
			
		}
	}
}
