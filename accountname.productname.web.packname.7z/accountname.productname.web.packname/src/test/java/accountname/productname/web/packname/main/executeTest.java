package accountname.productname.web.packname.main;

import java.io.IOException;

import org.omg.IOP.TransactionService;


public class executeTest extends BaseClass {
	public static ExcelReader datatable;
	public static String TransactionName;

	@Test
	public void Test() throws Exception {
		Extenteports report = ReportingHelper.initialiseReport("accountname.productname.web.packname");
		Utils.getApplicationInfo(report);
		execute();
		ReprotingHeloper.openReport();
	}

	private static void execute() throws IOException, InterruptedException {
		datatable = new ExcelReader (ProperReader.getProperty().testdatapath());
		int rowCount = datable.getRowCount();
		int row;

		int TransactionNo;
		int TransactionCount = 3;

		for (TransactionNo = 1; TransactionNo <= TransactionCount; TransactionNo++) {
			for (row = 1; row <= rowCount; row++) {
				try {
					TestSuite.setTestExecutionIndex (row);
					boolean isTags = CommonHelper.isTestable (TestSuite.getTestdata().getData ("ExecuteTag"));
					String status = datatable.getData ("ExecuteIndictor");
					if (status.equalsIgnoreCase("Y") && isTags) {
						TransactionName = datatable.getData ("Tranaction" + TransactionNo).trim();
						System.out.println("TransactionName :: "+TransactionName);
						String initExecStatus = datatable.getData ("Transaction" + String .valueOf(TransactionNo)+ "ExecustionStatus").trim();
						String cjId = datatable.getData ("CJ_ID").trim();
						String tcNum = datatable.getData ("Case_No").trim();
						if (TransactionName.equalsIgnoreCase("") == false && initExecStatus.equalsIgnoreCase("PASSED") == false) {
							ReportingHelper.startTestCaseReport (cjId+"_"+tcNum+"_"+datatable.getData ("Description").trim());
							Transactions.tansaction(TransactionName);
							TestSuite.setDatasheetName ("TestData");
							ExcelReader.updateExcel ("Transaction"+TransactionNo+"ExecutionStatus", "PASSED");
							AutomationExecutor.getDriver.quit();
							ReportingHelper.writeOutput ("Transaction Name : "+ TransactionName);
							ReportingHelper.endTestCaseReport ();
							BrowserHelper.absoluteWait (2);
						}

					}

				} catch (Exception e) {
					e.printStackTrace();
					BrowserHelper.captureScreenshot ("Failed");
					ReportingHelper.writeOutput (e.getMessage(), "Fail");
					TestSuite.setDatasheetName ("TestData");
					ExcelReader.updateExcel ("Transaction"+TransactionNo+"ExecutionStatus", "FAILED");
					ReportingHelper.writeOutput ("Transaction Name : "+ TransactionName);
					AutomationExecutor.getDriver.quit();
					BrowserHelper.absoluteWait (2);
					ReportingHelper.endTestCaseReport ();
				}

			}
		}
	}

}
